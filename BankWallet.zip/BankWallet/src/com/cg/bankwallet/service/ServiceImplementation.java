package com.cg.bankwallet.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bankwallet.bean.Wallet;
import com.cg.bankwallet.dao.DaoImplementation;

public class ServiceImplementation implements ServiceInterface {
	
	DaoImplementation dao = new DaoImplementation();
	
	public boolean isName(String name) {
		
		Pattern Name = Pattern.compile("[A-Z][a-z]+");
		Matcher match = Name.matcher(name);
		if(match.matches()==true){
			
			return true;
		}
		else{
			return false;
		}
	}
	
	public boolean isPhNum(String phNum){
		
		Pattern Num = Pattern.compile("[7-9][0-9]{9}");
		Matcher match = Num.matcher(phNum);
		if(match.matches()==true){
			
			return true;
		}
		else{
			return false;
		}
	}
	
	public boolean isEmail(String email){
		
		Pattern Email = Pattern.compile("");
		Matcher match = Email.matcher(email);
		if(match.matches()==true){
			return true;
		}
		else{
			return false;
		}
	}
	
	public boolean isAadhaar(String aadhaar){
		
		Pattern Aadhaar = Pattern.compile("[0-9]{12}$");
		Matcher match = Aadhaar.matcher(aadhaar);
		if(match.matches()==true){
			
			return true;
		}
		else{
			return false;
		}
	}
	
	
	
	
	

	@Override
	public Wallet createAccount(Wallet wallet) {
		
		return dao.createAccount(wallet);
	}

	@Override
	public Wallet showBalance(int accNumOfUser,int pin) {
		
		return dao.showBalance(accNumOfUser,pin);
	}

	@Override
	public Wallet deposit(double amount, int accNumOfUser) {
		
		return dao.deposit(amount, accNumOfUser);
	}

	@Override
	public Wallet withdraw(double amount, int accNumOfUser, int pin) {
		
		return dao.withdraw(amount, accNumOfUser, pin);
	}

	@Override
	public Wallet fundTransfer(double amount, int accNumOfUser,
			int accNumOfBeneficiary) {
		
		return dao.fundTransfer(amount, accNumOfUser, accNumOfBeneficiary);
	}

	@Override
	public Wallet printTransaction(int accNumOfUser, int pin) {
		
		return dao.printTransaction(accNumOfUser, pin);
	}

}
