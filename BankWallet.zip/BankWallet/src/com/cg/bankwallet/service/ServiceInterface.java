package com.cg.bankwallet.service;

import com.cg.bankwallet.bean.Wallet;

public interface ServiceInterface {
	
    public Wallet createAccount(Wallet wallet);
    public Wallet showBalance(int accNumOfUser,int pin);
    public Wallet deposit(double amount, int  accNumOfUser);
    public Wallet withdraw(double amount, int accNumOfUser, int pin);
    public Wallet fundTransfer(double amount, int accNumOfUser, int accNumOfBeneficiary);
    public Wallet printTransaction(int accNumOfUser, int pin);
	
	
	
	
	
}
      
