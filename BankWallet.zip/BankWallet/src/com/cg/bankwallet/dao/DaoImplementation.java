package com.cg.bankwallet.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bankwallet.bean.Wallet;

public class DaoImplementation implements DaoInterface {

	Map<Integer, Wallet> map = new HashMap<Integer, Wallet>();
	
	
	@Override
	public Wallet createAccount(Wallet wallet) {
	
		map.put(wallet.getAccNumOfUser(), wallet);
		
		return wallet;
	}

	@Override
	public Wallet showBalance(int accNumOfUser, int pin) {
		Wallet wbalance = null;
		for (Wallet wallet : map.values()) {
			if(accNumOfUser == wallet.getAccNumOfUser()&& pin == wallet.getPin()){
				
				wbalance = wallet;
			}else{
				System.out.println("Account Doesn't Exist");
				
			}
			
		}
		
		return wbalance;
	}

	@Override
	public Wallet deposit(double amount, int accNumOfUser) {
		double balance=0;
		Wallet w= null;
		for (Wallet wallet : map.values()) {
			if(accNumOfUser == wallet.getAccNumOfUser()){
				
			balance= wallet.getBalance();
			balance = balance+amount;
			wallet.setBalance(balance);
			System.out.println("Amount Successfully Deposited");
			System.out.println("Your Current Balance is: "+" "+ wallet.getBalance());
			
			w=wallet;
			}
			
		}
		return w;
	}

	@Override
	public Wallet withdraw(double amount, int accNumOfUser, int pin) {
		double balance=0;
		Wallet w1= null;
		for (Wallet wallet : map.values()) {
			if(accNumOfUser == wallet.getAccNumOfUser()&& pin ==wallet.getPin()){
				
			balance= wallet.getBalance();
			balance = balance-amount;
			wallet.setBalance(balance);
			System.out.println("Amount Successfully Withdarwn");
			System.out.println("Your Current Balance is: "+" "+ wallet.getBalance());
			
			w1=wallet;
			}
			
		}
		return w1;
		
	}

	@Override
	public Wallet fundTransfer(double amount, int accNumOfUser,
			int accNumOfBeneficiary) {

           double balance=0;
           Wallet w2 = null;
           for (Wallet wallet : map.values()) {
        	   if(accNumOfUser == wallet.getAccNumOfUser() && accNumOfBeneficiary == wallet.getAccNumOfBeneficiary()){
        		   balance = wallet.getBalance();
        		   balance = balance-amount;
        		  // balance1 = balance+amount;
        		   wallet.setBalance(balance);
        		   //wallet.setBalance(balance1);
        		   System.out.println("Amount Transferred Successfully");
        		   System.out.println("Your Current Balance is:"+ " "+wallet.getBalance());
        		 //  System.out.println("Balance in Beneficiary Account is:"+ " "+wallet.getBalance());
        		   
        		   w2 = wallet;
        	   }
			
		}
           
		return w2;
	}

	@Override
	public Wallet printTransaction(int accNumOfUser, int pin) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
