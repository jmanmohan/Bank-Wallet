package com.cg.bankwallet.exception;

public class WalletNotFound extends Exception{

}
