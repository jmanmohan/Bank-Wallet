package com.cg.bankwallet.ui;

import java.util.Random;
import java.util.Scanner;

import com.cg.bankwallet.bean.Wallet;
import com.cg.bankwallet.service.ServiceImplementation;

public class Presentation {

	public static void main(String[] args) {

		ServiceImplementation service = new ServiceImplementation();
		while (true) {

			System.out.println("Welcome");
			System.out.println("Please Enter Your Choice");
			System.out.println("1--Create Account");
			System.out.println("2--Show Balance");
			System.out.println("3--Deposit");
			System.out.println("4--Withdraw");
			System.out.println("5--Fund Transfer");
			System.out.println("6--Print Transactions");
			System.out.println("7--Exit");

			Wallet wallet = new Wallet();

			Scanner scanner = new Scanner(System.in);
			int choice = scanner.nextInt();
			switch (choice) {

			case 1:
				System.out.println("Please enter Your Name");
				String name = scanner.next();
				boolean valid_name = service.isName(name);
				boolean valid_name2;
				String name2;
				if (!valid_name) {
					do {
						System.out.println("Please Enter a Correct Name");
						name2 = scanner.next();
						valid_name2 = service.isName(name2);
					} while (!valid_name2);
					wallet.setNameOfUser(name2);
				} else {
					wallet.setNameOfUser(name);
				}

				System.out.println("Please enter Your Phone Number");
				String phNum = scanner.next();
				boolean valid_phNum = service.isPhNum(phNum);
				boolean valid_phNum2;
				String phNum2;
				if (!valid_phNum) {
					do {
						System.out
								.println("Please Enter a Correct Phone Number");
						phNum2 = scanner.next();
						valid_phNum2 = service.isPhNum(phNum2);
					} while (!valid_phNum2);
					wallet.setPhNumOfUser(phNum2);
				} else {
					wallet.setPhNumOfUser(phNum);
				}

				/*System.out.println("Please enter Your E-mail Address");
				String email = scanner.next();
				boolean valid_email = service.isEmail(email);
				boolean valid_email2;
				String email2;
				if (!valid_email) {
					do {
						System.out.println("Please Enter A Valid Email ID");
						email2 = scanner.next();
						valid_email2 = service.isEmail(email2);
					} while (!valid_email2);
					wallet.setEmailOfUser(email2);
				} else {
					wallet.setEmailOfUser(email);
				}*/

				System.out.println("Please enter Your Permanent Address");
				String address = scanner.next();
				wallet.setAddressOfUser(address);

				System.out.println("Please enter Your Aadhaar Number");
				String aadhaar = scanner.next();
				boolean valid_aadhaar = service.isAadhaar(aadhaar);
				boolean valid_aadhaar2;
				String aadhaar2;
				if (!valid_aadhaar) {
					do {
						System.out.println("Please Enter Valid Aadhaar Number");
						aadhaar2 = scanner.next();
						valid_aadhaar2 = service.isAadhaar(aadhaar2);
					} while (!valid_aadhaar2);
					wallet.setAadhaarOfUser(aadhaar2);
				} else {
					wallet.setAadhaarOfUser(aadhaar);
				}

				Random r1 = new Random();
				int accNumOfUser = 1000000 + r1.nextInt(9999);
				
				wallet.setAccNumOfUser(accNumOfUser);
				//Wallet isAdded = service.createAccount(wallet);

				Random r2 = new Random();
				int pin = 1000 + r2.nextInt(9000);
				
				wallet.setPin(pin);
				

				System.out.println("Please Enter Initial Balance");
				double balance = scanner.nextDouble();
				wallet.setBalance(balance);
				Wallet isAdded1 = service.createAccount(wallet);
				
				System.out.println("ACCOUNT CREATED" + " " +isAdded1);
				

				break;
			case 2:
				System.out.println("Enter Your Account Number");
				int accNum = scanner.nextInt();

				System.out.println("Please Enter Your Pin");
				int pin0 = scanner.nextInt();

				wallet.setAccNumOfUser(accNum);
				wallet.setPin(pin0);
				Wallet isAdded2 = service.showBalance(accNum, pin0);
				System.out.println("Balance in your Account is"+ " "+isAdded2.getBalance());
				break;

			case 3:
				System.out.println("Enter The Amount To Be Deposited");
				double depositAmount = scanner.nextDouble();
				System.out.println("Enter Account Number");
				int accNum1 = scanner.nextInt();

				wallet.setAmount(depositAmount);
				wallet.setAccNumOfUser(accNum1);
				wallet.getBalance();
				Wallet isAdded3 = service.deposit(depositAmount, accNum1);
			
				

				break;

			case 4:
				System.out.println("Enter The Amount To Be Withdrawn");
				double withdrawAmount = scanner.nextDouble();

				System.out.println("Enter The Account Number");
				int accNum2 = scanner.nextInt();

				System.out.println("Please Enter Your Pin");
				int pin1 = scanner.nextInt();

				wallet.setAmount(withdrawAmount);
				wallet.setAccNumOfUser(accNum2);
				Wallet isAdded4 = service.withdraw(withdrawAmount, accNum2,
						pin1);

				break;
			case 5:
				System.out.println("Enter Your Account Number");
				int accNum3 = scanner.nextInt();

				System.out.println("Enter Beneficiary Account Number");
				int accNumBen = scanner.nextInt();

				System.out.println("Please Enter The Amount To Be Transferred");
				double transferAmount = scanner.nextDouble();

				wallet.setAccNumOfUser(accNum3);
				wallet.setAccNumOfBeneficiary(accNumBen);
				wallet.setAmount(transferAmount);
				Wallet isAdded5 = service.fundTransfer(transferAmount, accNum3,
						accNumBen);

				break;
			case 6:
				System.out.println("Please Enter Account Number");
				int accNum4 = scanner.nextInt();

				System.out.println("Please enter Your Pin");
				int pin2 = scanner.nextInt();

				wallet.setAccNumOfUser(accNum4);
				wallet.setPin(pin2);
				Wallet isAdded6 = service.printTransaction(accNum4, pin2);

				break;
			default:
				System.out.println("Please Enter A Correct Choice");
				break;
			}

		}

	}

}
