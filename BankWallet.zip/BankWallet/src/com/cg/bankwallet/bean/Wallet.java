package com.cg.bankwallet.bean;

public class Wallet {

	private String nameOfUser;
	private String emailOfUser;
	private String addressOfUser;
	private String aadhaarOfUser;
	private String phNumOfUser;
	private double amount;
	private int accNumOfUser;
    private int pin;
    private int accNumOfBeneficiary;
	private double balance;

	

	public Wallet() {
	}

	

	public Wallet(String nameOfUser, String emailOfUser, String addressOfUser,
			String aadhaarOfUser, String phNumOfUser, double amount,
			int accNumOfUser, int pin, double balance, int accNumOfBeneficiary) {

		this.nameOfUser = nameOfUser;
		this.aadhaarOfUser = aadhaarOfUser;
		this.accNumOfUser = accNumOfUser;
		this.addressOfUser = addressOfUser;
		this.phNumOfUser = phNumOfUser;
		this.amount = amount;
		this.emailOfUser = emailOfUser;
		this.pin = pin;
        this.accNumOfBeneficiary = accNumOfBeneficiary;
        this.balance = balance;
	}

	public String getNameOfUser() {
		return nameOfUser;
	}

	public void setNameOfUser(String nameOfUser) {
		this.nameOfUser = nameOfUser;
	}

	public String getEmailOfUser() {
		return emailOfUser;
	}

	public void setEmailOfUser(String emailOfUser) {
		this.emailOfUser = emailOfUser;
	}

	public String getAddressOfUser() {
		return addressOfUser;
	}

	public void setAddressOfUser(String addressOfUser) {
		this.addressOfUser = addressOfUser;
	}

	public String getAadhaarOfUser() {
		return aadhaarOfUser;
	}

	public void setAadhaarOfUser(String aadhaarOfUser) {
		this.aadhaarOfUser = aadhaarOfUser;
	}

	public String getPhNumOfUser() {
		return phNumOfUser;
	}
	public int getAccNumOfBeneficiary() {
		return accNumOfBeneficiary;
	}

	public void setAccNumOfBeneficiary(int accNumOfBeneficiary) {
		this.accNumOfBeneficiary = accNumOfBeneficiary;
	}

	public void setPhNumOfUser(String phNum2) {
		this.phNumOfUser = phNum2;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getAccNumOfUser() {
		return accNumOfUser;
	}

	public void setAccNumOfUser(int accNumOfUser) {
		this.accNumOfUser = accNumOfUser;
	}
	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Wallet [Name=" + nameOfUser + ", E-mail="
				+ emailOfUser + ", Address=" + addressOfUser
				+ ", Aadhaar Number=" + aadhaarOfUser + ", Phone Number="
				+ phNumOfUser + ", Amount=" + amount + ", Account Number="
				+ accNumOfUser + ", Pin=" + pin + ", Beneficiary Account Number="
				+ accNumOfBeneficiary + ", Balance=" + balance + "]";
	}
	

	

}
