package com.capgemini.flp.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.flp.model.DeliveryDetails;
import com.capgemini.flp.service.IDeliveryService;

@Controller
public class MainController {

	@Autowired
	IDeliveryService service;

	@RequestMapping("/home")
	public String displayPage(Model model) {
		String view = "DeliveryDetails";
		ArrayList<DeliveryDetails> list = service.getAllDetails();
		model.addAttribute("delivery", list);
		return view;
	}

	 
}
