package com.capgemini.flp.service;

import java.util.ArrayList;

import com.capgemini.flp.model.DeliveryDetails;

public interface IDeliveryService {

	public ArrayList<DeliveryDetails> getAllDetails();

	
}
