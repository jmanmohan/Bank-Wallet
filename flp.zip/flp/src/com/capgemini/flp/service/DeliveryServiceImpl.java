package com.capgemini.flp.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.dao.IDeliveryDAO;
import com.capgemini.flp.model.DeliveryDetails;

@Service
@Transactional
public class DeliveryServiceImpl implements IDeliveryService{

	@Autowired
	IDeliveryDAO IDeliveryDao;
	
	

	/*@Override
	public String findHotelName() {
		return bookingDao.findHotelName();
	}*/

	@Override
	public ArrayList<DeliveryDetails> getAllDetails() {
		// TODO Auto-generated method stub
		return IDeliveryDao.getAllDetails();
	}

}
