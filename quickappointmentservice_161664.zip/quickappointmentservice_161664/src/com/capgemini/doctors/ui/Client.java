package com.capgemini.doctors.ui;

import java.util.Random;
import java.util.Scanner;

import com.capgemini.com.doctors.bean.DoctorAppointment;
import com.capgemini.com.doctors.exception.PatientNotFound;
import com.capgemini.com.doctors.service.DoctorAppointmentService;

/*
 @author : Saransh Kulshrestha
 Class: Client
 Date: 29/10/2018
 */

public class Client {

	public static void main(String[] args) { // main clas
		DoctorAppointmentService service = new DoctorAppointmentService();
		while (true) {

			System.out.println("Pres 1 -> Book Doctor Appointment"); // menu_driven_code
			System.out.println("Pres 2 -> View Doctor Appointment");
			System.out.println("Pres 3 -> Exit");

			Scanner sc = new Scanner(System.in);

			int ch = sc.nextInt();
			switch (ch) { // switch case for menu based selection
			case 1:
				DoctorAppointment bean = new DoctorAppointment();
				System.out.println("Enter Name of the patient");
				String patientName = sc.next();
				bean.setPatientName(patientName);

				System.out.println("Enter Phone Number");
				String phoneNumber = sc.next();
				bean.setPhoneNumber(phoneNumber);

				System.out.println("Enter Email");
				String email = sc.next();
				String cc_email;
				boolean valid_email = service.isEmail(email); // validation
																// emial
				boolean vvalid_email;
				if (!valid_email) {
					do {

						System.out.println("enter correct email:");
						cc_email = sc.next();
						vvalid_email = service.isEmail(cc_email);
					} while (!vvalid_email);
					bean.setEmail(cc_email);
				} else
					bean.setEmail(email);

				System.out.println("Enter Age"); // validation age
				int age = sc.nextInt();
				int cc_age;
				boolean valid_age = service.isAge(age);
				boolean vvalid_age = false;
				if (!valid_age) {
					do {

						System.out.println("enter correct age:");
						cc_age = sc.nextInt();
						vvalid_age = service.isAge(cc_age);
					} while (!vvalid_age);
					bean.setAge(cc_age);
				} else
					bean.setAge(age);

				System.out.println("Enter Gender");
				String gender = sc.next();
				bean.setGender(gender);

				System.out.println("Enter Problem Name"); // initialising
															// doctors name
				String problemName = sc.next();
				bean.setProblemName(problemName);

				if (problemName == "Heart") {
					String doctorName = "Dr. Brijesh Kumar";
					bean.setDoctorName(doctorName);
				} else if (problemName == "Gynecology") {
					String doctorName = "Dr. Sharda Singh";
					bean.setDoctorName(doctorName);
				} else if (problemName == "Diabetes") {
					String doctorName = "Dr. Heena Khan";
					bean.setDoctorName(doctorName);
				} else if (problemName == "ENT") {
					String doctorName = "Dr. Paras Mal";
					bean.setDoctorName(doctorName);
				} else if (problemName == "Bone") {
					String doctorName = "Dr. Renuka Kher";
					bean.setDoctorName(doctorName);
				} else if (problemName == "Dermatology") {
					String doctorName = "Dr. Kanika Kapoor";
					bean.setDoctorName(doctorName);
				} else {
					String doctorName = "NULL";
					bean.setDoctorName(doctorName);
				}
				if (problemName == bean.getProblemName()) {

					String appointmentStatus = "APPROVED";
					bean.setAppointmentStatus(appointmentStatus);
				} else {

					String appointmentStatus = "APPROVED";
					bean.setAppointmentStatus(appointmentStatus);
				}

				Random rd1 = new Random();
				int appointmentId = 1000 + rd1.nextInt(9999);
				System.out.println();
				bean.setAppointmentId(appointmentId);

				boolean isAdded = service.addPatient(appointmentId, bean); // calling
																			// add
																			// patient
																			// method
				boolean isValid = true;
				int a = bean.getAppointmentId();

				System.out
						.println("Your Doctor Appointment has been successfully redistered, your appointment ID is :"
								+ a);
				System.out.println(bean);

				break;
			case 2:
				System.out.println("Enter the appointment id");
				int app_id = sc.nextInt();
				boolean isVaalid = service.isAppid(app_id);
				if (!isVaalid) {
					System.out.println(" enet 4 digit id only");
				}

				DoctorAppointment bean1 = service.viewAppointment(app_id); // /calling
																			// view
																			// appointment
																			// method

				break;
			case 3:
				System.exit(0);
				break;

			default:
				System.out.println("please enter a valid choice choice");
				break;
			}

		}
	}
}