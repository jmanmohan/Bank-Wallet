package com.capgemini.com.doctors.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.com.doctors.bean.DoctorAppointment;

public class DoctorAppointmentDao implements IDoctorAppointmentDao {
	// implementation for dao interface
	Map<Integer, DoctorAppointment> custList = new HashMap<Integer, DoctorAppointment>();

	@Override
	public boolean addPatient(int appointmentId, DoctorAppointment bean) {
		custList.put(appointmentId, bean);
		System.out.println(custList);
		return false;
	}

	public DoctorAppointment viewAppointment(int app_id) {
		DoctorAppointment da = null;
		for (DoctorAppointment custList2 : custList.values()) {
			if (custList2.getAppointmentId() == app_id) {

				System.out.println("Patient Name : "
						+ custList2.getPatientName());

				System.out.println("Appointent Status :"
						+ custList2.getAppointmentStatus());

				System.out.println("Doctor Name :" + custList2.getDoctorName());

			}

			else {
				System.out.println("please enter valid pin and account number");

			}

		}
		return da;
	}
}
