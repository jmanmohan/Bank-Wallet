package com.capgemini.com.doctors.dao;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.fail;

import org.junit.Test;

public class DoctorAppointmentDaoTest {

	@Test
	public void testAddPatient() {
		assertFalse("not added", false);
		fail("Not yet implemented");
	}

	@Test
	public void testViewAppointment() {
		assertFalse(true);
		fail("Not yet implemented");
	}

}
