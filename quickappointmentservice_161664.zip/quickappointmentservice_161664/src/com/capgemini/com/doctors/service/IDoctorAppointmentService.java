package com.capgemini.com.doctors.service;

import com.capgemini.com.doctors.bean.DoctorAppointment;

public interface IDoctorAppointmentService { // defining interface of service
												// class
	public boolean addPatient(int appointmentId, DoctorAppointment bean);

	public DoctorAppointment viewAppointment(int app_id);

}
