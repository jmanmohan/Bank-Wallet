package com.capgemini.com.doctors.service;

import com.capgemini.com.doctors.bean.DoctorAppointment;
import com.capgemini.com.doctors.dao.DoctorAppointmentDao;

public class DoctorAppointmentService implements IDoctorAppointmentService {

	DoctorAppointmentDao dao = new DoctorAppointmentDao();

	public boolean isEmail(String email) {
		// validating email
		String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
		java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
		java.util.regex.Matcher m = p.matcher(email);
		return m.matches();
	}

	public boolean isAge(int age) {
		// validating age as age cannot be negative
		if (age <= 0) {

			return false;
		} else {
			return true;
		}

	}

	public boolean isAppid(int app_id) {
		if (app_id < 1000 && app_id > 9999) {
			return false;
		} else {
			return true;
		}
	}

	public boolean addPatient(int appointmentId, DoctorAppointment bean) {
		return dao.addPatient(appointmentId, bean);
	}

	public DoctorAppointment viewAppointment(int app_id) {

		return dao.viewAppointment(app_id);
	}

}
