package com.capgemini.com.doctors.exception;

public class PatientNotFound extends Exception {

	PatientNotFound() {
		super();
	}

	PatientNotFound(String message) {
		super(message);
	}
}
